import SpriteKit

/// Pixel-perfect player renderer built from the original 1987 24x32 sprite data.
/// Both normal Vitorc and the two-gun Exoskeleton use 10 walk frames + duck + die.
final class PlayerSpriteNode: SKSpriteNode {
    private static let frameCount = 12
    private static let frameSize = CGSize(width: 48, height: 64)

    private let normalFrames: [SKTexture]
    private let exoskeletonFrames: [SKTexture]
    private var displayedState: PlayerMotionState?
    private var displayedExoskeleton = false
    private var animationTimer: TimeInterval = 0
    private var animationIndex = 0

    private let runSequence = Array(0..<10)
    // The Spectrum game updates on a 50 Hz loop, but not every loop changes
    // the walk phase. 12 fps closely matches the original apparent cadence.
    private let runFrameDuration: TimeInterval = 1.0 / 12.0

    init() {
        normalFrames = Self.loadSheet(named: "vitorc_original")
        exoskeletonFrames = Self.loadSheet(named: "vitorc_exoskeleton")

        super.init(texture: normalFrames[0], color: .clear, size: Self.frameSize)
        name = "vitorc"
        anchorPoint = CGPoint(x: 0.5, y: 0.5)
        zPosition = 10
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func update(from player: Player, dt: TimeInterval) {
        xScale = player.facing == .left ? -1 : 1
        color = .white
        colorBlendFactor = 0

        let suitChanged = displayedExoskeleton != player.hasExoskeleton
        if displayedState != player.motionState || suitChanged {
            displayedState = player.motionState
            displayedExoskeleton = player.hasExoskeleton
            animationTimer = 0
            animationIndex = 0
            applyFirstFrame(for: player.motionState, exoskeleton: player.hasExoskeleton)
        }

        guard player.motionState == .running else { return }

        animationTimer += dt
        while animationTimer >= runFrameDuration {
            animationTimer -= runFrameDuration
            animationIndex = (animationIndex + 1) % runSequence.count
            texture = activeFrames(exoskeleton: player.hasExoskeleton)[runSequence[animationIndex]]
        }
    }

    private func activeFrames(exoskeleton: Bool) -> [SKTexture] {
        exoskeleton ? exoskeletonFrames : normalFrames
    }

    private func applyFirstFrame(for state: PlayerMotionState, exoskeleton: Bool) {
        let frames = activeFrames(exoskeleton: exoskeleton)
        switch state {
        case .idle:
            texture = frames[0]
        case .running:
            texture = frames[0]
        case .jumping:
            texture = frames[3]
        case .falling:
            texture = frames[8]
        case .crouching:
            texture = frames[10]
        case .dying:
            texture = frames[11]
        }
    }

    private static func loadSheet(named name: String) -> [SKTexture] {
        let sheet = SKTexture(imageNamed: name)
        sheet.filteringMode = .nearest
        let width = 1.0 / CGFloat(frameCount)
        return (0..<frameCount).map { index in
            let rect = CGRect(x: CGFloat(index) * width, y: 0, width: width, height: 1)
            let texture = SKTexture(rect: rect, in: sheet)
            texture.filteringMode = .nearest
            return texture
        }
    }
}
